// build: fix12m3 — align bars to cell start, auto row height, info panel
console.log('calendar_app_fix12m3.jsx loaded');

const { useState, useEffect, useMemo, useRef } = React;

/* ========== utils ========== */
const hh = (n)=> String(n).padStart(2,'0');
const isoDate = (d)=> d.toISOString().slice(0,10);
const startOfDay = (d)=> new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0,0,0,0);
const daysInMonth = (anchor)=> new Date(anchor.getFullYear(), anchor.getMonth()+1, 0).getDate();
const addDays = (date, delta)=> { const d=new Date(date); d.setDate(d.getDate()+delta); return d; };
const startOfWeekMonday = (d)=> { const nd=new Date(d); const day=(nd.getDay()+6)%7; nd.setDate(nd.getDate()-day); nd.setHours(0,0,0,0); return nd; };

/* ========== status meta ========== */
const STATUS_META = {
  "Планирана":    { bg:"bg-sky-50",    border:"border-sky-400",    pill:"bg-sky-100 text-sky-800" },
  "В изпълнение": { bg:"bg-amber-50",  border:"border-amber-400",  pill:"bg-amber-100 text-amber-800" },
  "Завършена":    { bg:"bg-emerald-50",border:"border-emerald-400",pill:"bg-emerald-100 text-emerald-800" },
  "Отменена":     { bg:"bg-rose-50",   border:"border-rose-400",   pill:"bg-rose-100 text-rose-800" },
  "Фактурирана":  { bg:"bg-indigo-50", border:"border-indigo-400", pill:"bg-indigo-100 text-indigo-800" },
};
const DEFAULT_STATUS = "Планирана";

/* ========== local storage flat ========== */
function lsGetFlat(){
  try{ const a = JSON.parse(localStorage.getItem('busops:orders_v1')||'[]'); return Array.isArray(a)?a:[]; }catch{ return []; }
}
function lsSetFlat(arr){
  try{
    localStorage.setItem('busops:orders_v1', JSON.stringify(arr||[]));
    localStorage.setItem('orders_fallback_store_v1', JSON.stringify(arr||[]));
  }catch{}
}
function emitChanged(){ try{ window.dispatchEvent(new CustomEvent('orders:changed')); }catch{} }

function flatReplaceAllById(id, fresh){
  const src = lsGetFlat();
  const rest = src.filter(x=> String(x.id)!==String(id));
  const merged = rest.concat(fresh);
  lsSetFlat(merged);
  emitChanged();
}
function flatSetStatus(id, status){
  const arr = lsGetFlat().map(r => String(r.id)===String(id) ? {...r, status} : r);
  lsSetFlat(arr); emitChanged();
}

/* ========== server calls (fire-and-forget) ========== */
function persistRangeOnServer(id, start_date, end_date, vehicle_plate, status){
  fetch('/orders/api/update_range', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ id, start_date, end_date, vehicle_plate, status })
  }).catch(()=>{});
}
function persistStatus(id, status){
  fetch('/orders/api/set_status', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ id:String(id), status:String(status) })
  }).catch(()=>{});
}

/* ========== data hooks ========== */
function useFlatOrders(){
  const [flat, setFlat] = useState([]);
  useEffect(()=>{
    let alive = true;
    (async function(){
      try{
        const r = await fetch('/orders/api/calendar_flat', {cache:'no-store'});
        const j = await r.json();
        const arr = Array.isArray(j.orders) ? j.orders : [];
        if(!alive) return;
        lsSetFlat(arr);
        setFlat(arr);
        emitChanged();
      }catch{
        setFlat(lsGetFlat());
      }
    })();
    const onChange = ()=> setFlat(lsGetFlat());
    window.addEventListener('orders:changed', onChange);
    return ()=> { alive=false; window.removeEventListener('orders:changed', onChange); };
  }, []);
  return flat;
}

function useLanes(){
  const [lanes, setLanes] = useState(["Неразпределени"]);
  useEffect(()=>{
    (async function(){
      try{
        const r = await fetch('/buses/api/list');
        const j = await r.json();
        const active = Array.from(new Set(j.active||[]));
        const inactive = Array.from(new Set(j.inactive||[]));
        const list = inactive.length ? ["Неразпределени", ...active, "НЕАКТИВНИ:", ...inactive] : ["Неразпределени", ...active];
        setLanes(list);
        window.__INACTIVE_PLATES__ = new Set(inactive||[]);
      }catch{}
    })();
  }, []);
  return lanes;
}

/* ========== build per-day per-lane ========== */
function buildByDayLane(days, lanes, flat){
  const map = new Map();
  days.forEach(d=>{
    const k = isoDate(d);
    const laneMap = new Map();
    lanes.forEach(l=>laneMap.set(l, []));
    map.set(k, laneMap);
  });
  (flat||[]).forEach(o=>{
    let plate = o.vehicle_plate || 'Неразпределени';
    if(!lanes.includes(plate)) plate = 'Неразпределени';
    const lm = map.get(o.date);
    if(lm) lm.get(plate).push(o);
  });
  return map;
}

/* ========== compute spans (continuous bars) ========== */
function computeSpans(days, lane, byDayLane){
  const spans = [];
  const dayKeys = days.map(isoDate);
  const byId = new Map();
  dayKeys.forEach((k, idx)=>{
    const list = (byDayLane.get(k)?.get(lane)) || [];
    list.forEach(o=>{
      const id = String(o.id);
      (byId.get(id) || byId.set(id, []).get(id)).push({ idx, o });
    });
  });
  byId.forEach(entries=>{
    entries.sort((a,b)=> a.idx - b.idx);
    let i=0;
    while(i<entries.length){
      const startIdx = entries[i].idx;
      const meta = entries[i].o;
      let j=i+1, last=startIdx;
      while(j<entries.length && entries[j].idx===last+1){ last=entries[j].idx; j++; }
      const len = last - startIdx + 1;
      spans.push({
        id: String(meta.id),
        startIdx, endIdx:last, len,
        title: meta.title || ('Поръчка #'+meta.id),
        startTime: meta.startTime || '08:00',
        endTime: meta.endTime || '10:00',
        description: meta.description || "",
        status: meta.status || DEFAULT_STATUS
      });
      i=j;
    }
  });
  return spans;
}

/* ========== assign stack levels (prevent overlap) ========== */
function assignLevels(spans){
  const sorted = [...spans].sort((a,b)=> a.startIdx - b.startIdx || a.endIdx - b.endIdx);
  const ends=[];
  sorted.forEach(sp=>{
    let lvl=0;
    while(ends[lvl]!=null && ends[lvl] >= sp.startIdx) lvl++;
    ends[lvl] = sp.endIdx;
    sp._level = lvl;
  });
  return { spans: sorted, maxLevel: Math.max(0, ends.length-1) };
}

/* ========== DnD full-range ========== */
function useDragAndDrop(){
  const allowDrop = (e)=> e.preventDefault();
  const onDragStart = (e, id)=> e.dataTransfer.setData('text/plain', String(id));
  const onDragEnd = ()=>{};

  function onDropToCell(date, lane){
    return (e)=>{
      e.preventDefault();
      const id = e.dataTransfer.getData('text/plain');
      if(!id) return;
      // взимаме текущия диапазон за тази поръчка (от LS)
      const all = lsGetFlat().filter(x=> String(x.id)===String(id)).sort((a,b)=> (a.date<b.date?-1: a.date>b.date?1:0));
      if(!all.length) return;
      const firstDate = new Date(all[0].date+'T00:00:00');
      const lastDate  = new Date(all[all.length-1].date+'T00:00:00');
      const daysCount = Math.round((lastDate-firstDate)/(24*3600*1000)) + 1;

      const newStart = new Date(date.getFullYear(), date.getMonth(), date.getDate());
      const newEnd   = addDays(newStart, daysCount-1);

      const first = all[0];
      const [sh,sm] = String(first.startTime||'08:00').split(':').map(x=>parseInt(x||0,10));
      const [eh,em] = String(first.endTime||'10:00').split(':').map(x=>parseInt(x||0,10));
      const title = first.title || ('Поръчка #'+id);
      const status = first.status || DEFAULT_STATUS;
      const desc = first.description || "";
      const plate = (lane==='Неразпределени' || lane==='НЕАКТИВНИ:') ? '' : lane;

      const fresh = [];
      for(let i=0;i<daysCount;i++){
        const d = addDays(newStart, i);
        fresh.push({
          id: String(id),
          date: isoDate(d),
          startTime: hh(sh)+':'+hh(sm),
          endTime: hh(eh)+':'+hh(em),
          title, vehicle_plate: plate, status, description: desc
        });
      }
      flatReplaceAllById(id, fresh);
      persistRangeOnServer(String(id), isoDate(newStart), isoDate(newEnd), plate, status);
    };
  }
  return { allowDrop, onDragStart, onDragEnd, onDropToCell };
}

/* ========== status popup ========== */
const StatusMenu = {
  el: null, onPick: null,
  ensure(){
    if(this.el) return this.el;
    const div = document.createElement('div');
    div.className = "fixed z-50 bg-white border rounded-xl shadow p-1 text-sm";
    div.style.display = 'none';
    const opts = ["Планирана","В изпълнение","Завършена","Отменена","Фактурирана"];
    div.innerHTML = opts.map(s=> `<button data-status="${s}" class="w-full text-left px-3 py-1 rounded hover:bg-slate-100">${s}</button>`).join('');
    div.addEventListener('click', (e)=>{
      const btn = e.target.closest('button[data-status]');
      if(!btn) return;
      const st = btn.getAttribute('data-status');
      const cb = this.onPick; this.hide();
      if(typeof cb==='function') cb(st);
    });
    document.body.appendChild(div);
    this.el = div; return div;
  },
  show(x, y, current, onPick){
    const el = this.ensure();
    this.onPick = onPick;
    el.querySelectorAll('button').forEach(b=>{
      const st = b.getAttribute('data-status');
      b.classList.toggle('bg-slate-100', st===current);
      b.classList.toggle('font-medium', st===current);
    });
    el.style.left = x+'px';
    el.style.top  = y+'px';
    el.style.display = 'block';
    setTimeout(()=> document.addEventListener('mousedown', this._hideOnce = (ev)=>{ if(!el.contains(ev.target)) this.hide(); }, {once:true}), 0);
  },
  hide(){ if(this.el) this.el.style.display='none'; this.onPick = null; }
};

/* ========== LaneRow (align + auto height) ========== */
function LaneRow({lane, days, byDayLane, onDropCell, allowDrop, dnd, onPickStatus, setSelectedId}){
  const rowRef = useRef(null);
  const [cellW, setCellW] = useState(60);

  const spansRaw = useMemo(()=> computeSpans(days, lane, byDayLane), [days, lane, byDayLane]);
  const { spans, maxLevel } = useMemo(()=> assignLevels(spansRaw), [spansRaw]);

  // бар височина и отмествания
  const barH = 37, gap = 6, padTop = 8, padBottom = 8;
  const overlayHeight = padTop + (maxLevel+1)*barH + maxLevel*gap + padBottom;

  useEffect(()=>{
    const measure = ()=>{
      const el = rowRef.current;
      if(!el) return;
      const cell = el.querySelector('[data-cell]');
      if(cell){
        const w = cell.getBoundingClientRect().width;
        if(w>0) setCellW(w);
      }
    };
    measure();
    window.addEventListener('resize', measure);
    return ()=> window.removeEventListener('resize', measure);
  }, [overlayHeight]);

  function barClass(status){
    const meta = STATUS_META[status] || STATUS_META[DEFAULT_STATUS];
    return `pointer-events-auto absolute top-0 left-0 text-[11px] px-2 py-[5px] rounded border cursor-move truncate ${meta.bg} ${meta.border}`;
  }

  function onBarClick(e, sp){
    setSelectedId && setSelectedId(String(sp.id));
    StatusMenu.show(e.clientX, e.clientY, sp.status, (picked)=>{
      flatSetStatus(sp.id, picked); // моментално в UI
      persistStatus(sp.id, picked); // бекенд
      onPickStatus && onPickStatus(sp.id, picked);
    });
  }

  return (
    <div className="relative" style={{minHeight: overlayHeight+'px'}}>
      {/* grid cells: даваме ИМ същата minHeight, за да няма разминаване */}
      <div ref={rowRef} className="grid" style={{gridTemplateColumns:`repeat(${days.length}, minmax(0, 1fr))`}}>
        {days.map((d,i)=>(
          <div key={i}
               data-cell
               className="border-r border-b p-1.5"
               style={{minHeight: overlayHeight+'px'}}
               onDragOver={allowDrop}
               onDrop={onDropCell(d, lane)} />
        ))}
      </div>
      {/* overlay bars — ляв ръб = точно началото на клетката */}
      <div className="pointer-events-none absolute inset-0">
        {spans.map(sp=>{
          const left = sp.startIdx * cellW;          // НЯМА вътрешен padding → приляга в лявата граница
          const width = sp.len * cellW - 1;          // −1 px заради граници, да не „прелива“
          const top = padTop + sp._level*(barH + gap);
          const meta = STATUS_META[sp.status] || STATUS_META[DEFAULT_STATUS];
          const desc = sp.description ? (' — ' + sp.description) : '';
          return (
            <div key={sp.id + ':' + sp.startIdx}
                 className={barClass(sp.status)}
                 style={{left:left+'px', width:Math.max(24,width)+'px', top:top+'px', height:(barH-6)+'px'}}
                 draggable
                 onDragStart={(e)=>dnd.onDragStart(e, sp.id)}
                 onClick={(e)=> onBarClick(e, sp)}
                 title={`${sp.title} · ${sp.startTime}-${sp.endTime}${desc}`}>
              <span className="font-medium">{sp.title}</span>
              {sp.description ? <span className="opacity-80">{desc}</span> : null}
              <span className={`ml-2 inline-block align-middle text-[10px] px-1 py-[1px] rounded ${meta.pill}`}>{sp.status}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ========== Views (Month/Week/Day) ========== */
function MonthView({anchor, flat, lanes, dnd, setSelectedId, setInfoSummary}){
  const total = daysInMonth(anchor);
  const days = useMemo(()=> Array.from({length: total}).map((_,i)=> new Date(anchor.getFullYear(), anchor.getMonth(), i+1)), [anchor,total]);
  const byDayLane = useMemo(()=> buildByDayLane(days, lanes, flat), [days, lanes, flat]);

  // за инфо панела – при клик пазим последната селекция (прави се в LaneRow чрез setSelectedId)

  return (
    <div className="bg-white border rounded-xl overflow-hidden">
      <div className="px-3 py-2 border-b text-sm font-semibold flex items-center justify-between">
        <div>Месец – {anchor.toLocaleDateString('bg-BG',{month:'long',year:'numeric'})}</div>
        <div className="text-xs text-slate-500">Клик за статус · Диапазон DnD</div>
      </div>
      <div className="overflow-x-auto">
        <div className="grid w-full" style={{gridTemplateColumns:`auto repeat(${days.length}, minmax(0, 1fr))`}}>
          <div className="h-8 border-r border-b bg-slate-50"></div>
          {days.map((d,i)=>(<div key={i} className="h-8 border-b p-1.5 text-[10px] text-center font-semibold">{d.getDate()}</div>))}
          {lanes.map((lane,ri)=>(
            <React.Fragment key={lane}>
              <div className="border-r border-b px-2 py-2 text-xs font-medium"
                   style={{height:'100%'}}>{lane}</div>
              <div style={{gridColumn:`span ${days.length}`}}>
                <LaneRow
                  lane={lane} days={days} byDayLane={byDayLane}
                  onDropCell={(d,l)=> dnd.onDropToCell(d,l)}
                  allowDrop={lane==='НЕАКТИВНИ:' ? undefined : dnd.allowDrop}
                  dnd={dnd}
                  setSelectedId={setSelectedId}
                />
              </div>
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}

function WeekView({anchor, flat, lanes, dnd, setSelectedId}){
  const start = startOfWeekMonday(anchor);
  const days = useMemo(()=> Array.from({length:7}).map((_,i)=> addDays(start,i)), [anchor]);
  const byDayLane = useMemo(()=> buildByDayLane(days, lanes, flat), [days, lanes, flat]);

  return (
    <div className="bg-white border rounded-xl overflow-hidden">
      <div className="px-3 py-2 border-b text-sm font-semibold">Седмица</div>
      <div className="overflow-x-auto">
        <div className="grid w-full" style={{gridTemplateColumns:`auto repeat(7, minmax(0, 1fr))`}}>
          <div className="h-8 border-r border-b bg-slate-50"></div>
          {days.map((d,i)=>(<div key={i} className="h-8 border-b p-1.5 text-[10px] text-center font-semibold">{d.toLocaleDateString('bg-BG',{weekday:'short', day:'2-digit'})}</div>))}
          {lanes.map((lane,ri)=>(
            <React.Fragment key={lane}>
              <div className="border-r border-b px-2 py-2 text-xs font-medium">{lane}</div>
              <div style={{gridColumn:'span 7'}}>
                <LaneRow
                  lane={lane} days={days} byDayLane={byDayLane}
                  onDropCell={(d,l)=> dnd.onDropToCell(d,l)}
                  allowDrop={lane==='НЕАКТИВНИ:' ? undefined : dnd.allowDrop}
                  dnd={dnd}
                  setSelectedId={setSelectedId}
                />
              </div>
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}

function DayView({anchor, flat, lanes, dnd, setSelectedId}){
  const day = startOfDay(anchor);
  const byDayLane = useMemo(()=> buildByDayLane([day], lanes, flat), [anchor, lanes, flat]);

  return (
    <div className="bg-white border rounded-xl overflow-hidden">
      <div className="px-3 py-2 border-b text-sm font-semibold">Ден – {day.toLocaleDateString('bg-BG')}</div>
      <div className="overflow-x-auto">
        <div className="grid w-full" style={{gridTemplateColumns:`auto minmax(0, 1fr)`}}>
          <div className="h-8 border-r border-b bg-slate-50"></div>
          <div className="h-8 border-b p-1.5 text-[10px] text-center font-semibold">Поръчки</div>
          {lanes.map((lane,ri)=>(
            <React.Fragment key={lane}>
              <div className="border-r border-b px-2 py-2 text-xs font-medium">{lane}</div>
              <div>
                <LaneRow
                  lane={lane} days={[day]} byDayLane={byDayLane}
                  onDropCell={(d,l)=> dnd.onDropToCell(d,l)}
                  allowDrop={lane==='НЕАКТИВНИ:' ? undefined : dnd.allowDrop}
                  dnd={dnd}
                  setSelectedId={setSelectedId}
                />
              </div>
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ========== Info panel helper ========== */
function summarizeOrder(flat, id){
  const group = flat.filter(o=> String(o.id)===String(id)).sort((a,b)=> (a.date<b.date?-1: a.date>b.date?1:0));
  if(!group.length) return null;
  const t = group[0];
  return {
    id: String(id),
    title: t.title || ('Поръчка #'+id),
    plate: t.vehicle_plate || '',
    start_date: group[0].date,
    end_date: group[group.length-1].date,
    startTime: t.startTime || '08:00',
    endTime: t.endTime || '10:00',
    days: group.length,
    description: t.description || '',
    status: t.status || DEFAULT_STATUS
  };
}

/* ========== App ========== */
function App(){
  const [view, setView] = useState('month');
  const [anchor, setAnchor] = useState(new Date());
  const [selectedId, setSelectedId] = useState(null);

  const flat = useFlatOrders();
  const lanes = useLanes();
  const dnd = useDragAndDrop();

  const summary = useMemo(()=> selectedId ? summarizeOrder(flat, selectedId) : null, [flat, selectedId]);

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2 bg-white border rounded-xl px-3 py-2">
        {view==='month' ? (
          <>
            <button className="px-3 py-1.5 rounded-xl border" onClick={()=>{ const d=new Date(anchor); d.setMonth(d.getMonth()-1); setAnchor(d); }}>«</button>
            <div className="font-semibold text-sm">{anchor.toLocaleDateString('bg-BG', {month:'long', year:'numeric'})}</div>
            <button className="px-3 py-1.5 rounded-xl border" onClick={()=>{ const d=new Date(anchor); d.setMonth(d.getMonth()+1); setAnchor(d); }}>»</button>
          </>
        ) : (
          <>
            <button className="px-3 py-1.5 rounded-xl border" onClick={()=>{ const d=new Date(anchor); d.setDate(d.getDate()+(view==='week'?-7:-1)); setAnchor(d); }}>{view==='week'?'« 7':'« 1'}</button>
            <div className="font-semibold text-sm">{anchor.toLocaleDateString('bg-BG')}</div>
            <button className="px-3 py-1.5 rounded-xl border" onClick={()=>{ const d=new Date(anchor); d.setDate(d.getDate()+(view==='week'?7:1)); setAnchor(d); }}>{view==='week'?'7 »':'1 »'}</button>
          </>
        )}
        <div className="ml-2">
          <button className={"px-2 py-1 text-xs rounded "+(view==='day'?'bg-slate-900 text-white':'border')} onClick={()=>setView('day')}>Ден</button>
          <button className={"ml-1 px-2 py-1 text-xs rounded "+(view==='week'?'bg-slate-900 text-white':'border')} onClick={()=>setView('week')}>Седмица</button>
          <button className={"ml-1 px-2 py-1 text-xs rounded "+(view==='month'?'bg-slate-900 text-white':'border')} onClick={()=>setView('month')}>Месец</button>
        </div>
        <a href="/orders#new" className="ml-2 px-3 py-1.5 text-sm rounded-xl border">+ Нова поръчка</a>
      </div>

      {/* Views */}
      {view==='month' && <MonthView anchor={anchor} flat={flat} lanes={lanes} dnd={dnd} setSelectedId={setSelectedId} />}
      {view==='week'  && <WeekView  anchor={anchor} flat={flat} lanes={lanes} dnd={dnd} setSelectedId={setSelectedId} />}
      {view==='day'   && <DayView   anchor={anchor} flat={flat} lanes={lanes} dnd={dnd} setSelectedId={setSelectedId} />}

      {/* Info panel (restored) */}
      <div className="bg-white border rounded-xl p-4">
        <div className="text-sm font-semibold mb-2">Информация за поръчка</div>
        {summary ? (
          <div className="space-y-1 text-sm">
            <div className="font-medium">{summary.title}</div>
            <div className="text-slate-600">
              Диапазон: {summary.start_date} → {summary.end_date} ({summary.days} дни) · Часове: {summary.startTime}–{summary.endTime}
            </div>
            <div className="text-slate-600">Автобус: {summary.plate || '—'}</div>
            <div className="text-slate-600">
              Статус: <span className={(STATUS_META[summary.status]||STATUS_META[DEFAULT_STATUS]).pill + " px-2 py-0.5 rounded"}>{summary.status}</span>
            </div>
            {summary.description ? <div className="text-slate-700">Описание: {summary.description}</div> : null}
            <div className="flex items-center gap-2 pt-1">
              <a href="/orders/" className="px-3 py-1.5 text-xs rounded-lg border">Отвори в „Поръчки“</a>
            </div>
          </div>
        ) : (
          <div className="text-sm text-slate-500">Избери поръчка от календара.</div>
        )}
      </div>
    </div>
  );
}

/* mount */
const root = ReactDOM.createRoot(document.getElementById('app'));
root.render(<App/>);
