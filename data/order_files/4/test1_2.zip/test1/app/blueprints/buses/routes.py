from flask import render_template, request, redirect, url_for, flash, jsonify
from . import bp
import json
from pathlib import Path
from datetime import datetime

# Пътища / storage
ROOT = Path(__file__).resolve().parents[3]  # /app/blueprints/buses/ -> project root
DATA_FILE = ROOT / "data" / "buses.json"

def _load():
    if not DATA_FILE.exists():
        DATA_FILE.parent.mkdir(exist_ok=True)
        DATA_FILE.write_text(json.dumps({"buses": [], "next_bus_id": 1}, ensure_ascii=False))
    return json.loads(DATA_FILE.read_text(encoding="utf-8"))

def _save(store):
    DATA_FILE.write_text(json.dumps(store, ensure_ascii=False, indent=2), encoding="utf-8")


# ---------- /buses ----------
@bp.route("/", methods=["GET", "POST"])
def index():
    store = _load()
    if request.method == "POST":
        form = request.form

        def _num(v, cast=float):
            try:
                return cast(v) if v not in ("", None) else None
            except Exception:
                return None

        bus = {
            "id": store.get("edit_bus_id") or store["next_bus_id"],
            "reg_no": (form.get("reg_no") or "").strip(),
            "seats": _num(form.get("seats"), int),
            "tech_inspection_date": form.get("tech_inspection_date") or None,
            "fuel_consumption": _num(form.get("fuel_consumption")),
            "tank_size": _num(form.get("tank_size"), int),
            "insurance_cost": _num(form.get("insurance_cost")),
            "monthly_credit": _num(form.get("monthly_credit")),
            "service_log": []
        }

        existing = next((b for b in store["buses"] if b["id"] == bus["id"]), None)
        if existing:
            # запази сервизната книжка
            bus["service_log"] = existing.get("service_log", [])
            for k, v in bus.items():
                existing[k] = v
            flash("Автобусът е обновен.", "success")
        else:
            store["buses"].append(bus)
            store["next_bus_id"] += 1
            flash("Автобусът е добавен.", "success")

        _save(store)
        return redirect(url_for("buses.index"))

    # GET
    buses = sorted(_load()["buses"], key=lambda b: (b.get("reg_no") or "").lower())
    return render_template("buses/index.html", page="buses", buses=buses)


@bp.route("/delete/<int:bus_id>", methods=["POST"])
def delete_bus(bus_id):
    store = _load()
    bus = next((b for b in store["buses"] if b["id"] == bus_id), None)
    if not bus:
        flash("Автобус не е намерен.", "warning")
        return redirect(url_for("buses.index"))

    if bus.get("has_orders"):
        bus["inactive"] = True
        flash("Автобусът има поръчки — преместен е в НЕАКТИВНИ.", "info")
    else:
        store["buses"] = [b for b in store["buses"] if b["id"] != bus_id]
        flash("Автобусът е изтрит.", "success")

    _save(store)
    return redirect(url_for("buses.index"))


# ---------- Сервизна книжка (ОБЕДИНЕНО: GET + POST) ----------
@bp.route("/service/<int:bus_id>", methods=["GET", "POST"])
def service_book(bus_id):
    store = _load()
    buses_sorted = sorted(store.get("buses", []), key=lambda x: int(x.get("id")))
    bus = next((b for b in buses_sorted if int(b.get("id")) == int(bus_id)), None)
    if not bus:
        flash("Автобус не е намерен.", "warning")
        return redirect(url_for("buses.index"))

    if request.method == "POST":
        form = request.form
        entry = {
            "id": (max([e.get("id", 0) for e in bus.get("service_log", [])]) if bus.get("service_log") else 0) + 1,
            "date": form.get("date") or datetime.utcnow().date().isoformat(),
            "kind": form.get("kind") or "repair",  # repair | expense
            "title": (form.get("title") or "").strip(),
            "amount": float(form.get("amount")) if form.get("amount") else 0.0,
            "notes": (form.get("notes") or "").strip()
        }
        bus.setdefault("service_log", []).append(entry)
        _save(store)
        flash("Записът е добавен.", "success")
        return redirect(url_for("buses.service_book", bus_id=bus_id))

    # prev / next навигация
    idx = next((i for i, b in enumerate(buses_sorted) if int(b.get("id")) == int(bus_id)), None)
    prev_id = buses_sorted[idx - 1]["id"] if idx is not None and idx > 0 else None
    next_id = buses_sorted[idx + 1]["id"] if idx is not None and idx < len(buses_sorted) - 1 else None

    total_repairs = sum(e.get("amount", 0.0) for e in bus.get("service_log", []) if e.get("kind") == "repair")
    total_expenses = sum(e.get("amount", 0.0) for e in bus.get("service_log", []) if e.get("kind") == "expense")

    return render_template(
        "buses/service_book.html",
        page="buses",
        bus=bus,
        total_repairs=total_repairs,
        total_expenses=total_expenses,
        prev_id=prev_id,
        next_id=next_id
    )


@bp.route("/service/<int:bus_id>/delete/<int:entry_id>", methods=["POST"])
def delete_service_entry(bus_id, entry_id):
    store = _load()
    bus = next((b for b in store["buses"] if b["id"] == bus_id), None)
    if not bus:
        flash("Невалиден автобус.", "danger")
        return redirect(url_for("buses.index"))

    before = len(bus.get("service_log", []))
    bus["service_log"] = [e for e in bus.get("service_log", []) if e.get("id") != entry_id]
    _save(store)
    flash("Записът е изтрит." if len(bus["service_log"]) < before else "Записът не е намерен.", "info")
    return redirect(url_for("buses.service_book", bus_id=bus_id))


# ---------- API ----------
@bp.route('/api/list')
def api_list():
    store = _load()
    active, inactive = [], []
    for b in store.get("buses", []):
        plate = b.get("reg_no") or b.get("reg") or b.get("plate")
        if not plate:
            continue
        (inactive if b.get("inactive") else active).append(plate)
    return jsonify({"active": active, "inactive": inactive, "buses": store.get("buses", [])})


@bp.route('/api/mark_used', methods=['POST'])
def api_mark_used():
    try:
        payload = request.get_json(force=True) or {}
    except Exception:
        payload = {}
    plate = (payload.get("plate") or "").strip()
    if not plate:
        return jsonify({"ok": False, "error": "missing plate"}), 400

    store = _load()
    changed = False
    for b in store.get("buses", []):
        p = b.get("reg_no") or b.get("reg") or b.get("plate")
        if p == plate:
            if not b.get("has_orders"):
                b["has_orders"] = True
                changed = True
            break
    if changed:
        _save(store)
    return jsonify({"ok": True, "changed": changed})


@bp.route('/api/set_inactive', methods=['POST'])
def api_set_inactive():
    try:
        payload = request.get_json(force=True) or {}
    except Exception:
        payload = {}
    plate = (payload.get("plate") or "").strip()
    bus_id = payload.get("bus_id")

    store = _load()
    bus = None
    if plate:
        bus = next((b for b in store.get("buses", []) if (b.get("reg_no") or b.get("reg") or b.get("plate")) == plate), None)
    if not bus and bus_id:
        bus = next((b for b in store.get("buses", []) if int(b.get("id")) == int(bus_id)), None)
    if not bus:
        return jsonify({"ok": False, "error": "bus not found"}), 404

    bus["inactive"] = True
    _save(store)
    return jsonify({"ok": True})


# ---------- Тoggle статус с plain POST за бутоните ----------
@bp.route('/set_inactive/<int:bus_id>', methods=['POST'])
def set_inactive(bus_id):
    store = _load()
    bus = next((b for b in store.get("buses", []) if int(b.get("id")) == int(bus_id)), None)
    if not bus:
        flash("Автобус не е намерен.", "warning")
        return redirect(url_for("buses.index"))

    # Тук можеш да добавиш СЪРВЪРНА проверка за бъдещи поръчки, ако ги пазиш на сървър.
    bus["inactive"] = True
    _save(store)
    flash("Автобусът е маркиран като неактивен.", "success")
    return redirect(url_for("buses.index"))


@bp.route('/set_active/<int:bus_id>', methods=['POST'])
def set_active(bus_id):
    store = _load()
    bus = next((b for b in store.get("buses", []) if int(b.get("id")) == int(bus_id)), None)
    if not bus:
        flash("Автобус не е намерен.", "warning")
        return redirect(url_for("buses.index"))

    bus["inactive"] = False
    _save(store)
    flash("Автобусът е активиран.", "success")
    return redirect(url_for("buses.index"))
