# -*- coding: utf-8 -*-
from flask import (
    render_template,
    jsonify,
    request,
    redirect,
    url_for,
    Blueprint,
    flash,
    Flask,
)
from pathlib import Path
import json
import datetime

# Само ЕДНА дефиниция на blueprint-а тук.
bp = Blueprint("orders", __name__, url_prefix="/orders", template_folder="templates")

# Пътища към файлове с данни
ROOT = Path(__file__).resolve().parents[3]
DATA_DIR = ROOT / "data"
ORDERS_FILE = DATA_DIR / "orders.json"
BUSES_FILE = DATA_DIR / "buses.json"

# Страни: основен файл (settings.json) + fallback (countries.json)
COUNTRIES_FILE_MAIN = DATA_DIR / "settings.json"
COUNTRIES_FILE_FALLBACK = DATA_DIR / "countries.json"


# ------------------ storage helpers ------------------
def _load_json(path: Path, default):
    """Чете JSON файл; ако липсва — създава го с подадения default."""
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")
    data = json.loads(path.read_text(encoding="utf-8"))
    # Гарантирай default статус „Планирана“ при липса
    if isinstance(data, dict):
        for o in data.get("orders", []) or []:
            if not o.get("status"):
                o["status"] = "Планирана"
    return data


def _save_json(path: Path, data):
    """Записва JSON; подсигурява статус за всяка поръчка."""
    if isinstance(data, dict):
        for o in data.get("orders", []) or []:
            if not o.get("status"):
                o["status"] = "Планирана"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _ymd(d: datetime.date) -> str:
    return d.strftime("%Y-%m-%d")


def _daterange(s: datetime.date, e: datetime.date):
    one = datetime.timedelta(days=1)
    d = s
    while d <= e:
        yield d
        d += one


def _parse_iso_date(s):
    try:
        return datetime.date.fromisoformat(str(s))
    except Exception:
        return None


def _load_countries():
    """
    Чете страните от settings.json (ако го има),
    иначе ползва fallback към countries.json.
    Връща list от обекти: { name, fee_per_km, fuel_price, vat_percent, ... }
    """
    if COUNTRIES_FILE_MAIN.exists():
        data = _load_json(COUNTRIES_FILE_MAIN, {"countries": []})
        return data.get("countries", [])
    if COUNTRIES_FILE_FALLBACK.exists():
        data = _load_json(COUNTRIES_FILE_FALLBACK, {"countries": []})
        return data.get("countries", [])
    return []


def _load_bus_plates():
    """
    Взима рег. номера на автобуси от buses.json: reg_no / reg / plate.
    Връща сортиран списък без дубликати.
    """
    buses_store = _load_json(BUSES_FILE, {"buses": [], "next_bus_id": 1})
    plates = []
    for b in buses_store.get("buses", []) or []:
        p = b.get("reg_no") or b.get("reg") or b.get("plate")
        if p:
            plates.append(str(p))
    # махаме дубликати и сортираме case-insensitive
    return sorted(list(dict.fromkeys(plates)), key=lambda x: x.lower())


def _find_order(store: dict, oid) -> dict | None:
    """Намира поръчка по id (стринг/инт)."""
    sid = str(oid)
    for o in store.get("orders", []) or []:
        if str(o.get("id")) == sid:
            return o
    return None


# ------------------ app factory (по желание) ------------------
def create_app():
    """
    Минимална фабрика на приложението, която регистрира ТОЗИ blueprint.
    Началната страница редиректва към /orders/entry.
    """
    app = Flask(__name__)
    app.config["SECRET_KEY"] = "change-me"

    app.register_blueprint(bp)  # url_prefix се взима от bp.url_prefix -> "/orders"

    @app.get("/")
    def _root():
        return redirect(url_for("orders.entry"))

    return app


# ------------------ views ------------------
@bp.get("/", endpoint="index")
def index():
    """Главен екран: рендерира orders/empty.html (както посочи)."""
    return render_template("orders/empty.html", page="orders")


@bp.get("/entry", endpoint="entry")
def orders_entry():
    """
    Форма за нова поръчка (подаваме bus_plates и countries).
    Ако има ?id=..., зарежда за редакция.
    """
    bus_plates = _load_bus_plates()
    countries = _load_countries()

    oid = request.args.get("id")
    order = None
    if oid:
        store = _load_json(ORDERS_FILE, {"orders": [], "next_id": 1})
        order = _find_order(store, oid)

    return render_template(
        "orders/entry.html",
        page="orders_entry",
        bus_plates=bus_plates,
        countries=countries,
        order=order,
    )


@bp.get("/list", endpoint="list")
def orders_list():
    """
    Списък на поръчките: разделени в 2 контейнера:
      1) Текущи: start_date >= днес (подредени по start_date възходящо)
      2) Архив: всички останали (end_date < днес), подредени по end_date низходящо
    """
    store = _load_json(ORDERS_FILE, {"orders": [], "next_id": 1})
    raw = store.get("orders", []) or []

    today = datetime.date.today()

    current, archive = [], []

    for o in raw:
        sd = _parse_iso_date(o.get("start_date") or o.get("date"))
        ed = _parse_iso_date(o.get("end_date") or o.get("date") or o.get("start_date") or "")
        if sd and sd >= today:
            current.append(o)
        else:
            # липса на sd или sd < today -> архив
            archive.append(o)

    # сортиране
    current.sort(key=lambda x: (x.get("start_date") or ""))
    archive.sort(
        key=lambda x: (x.get("end_date") or x.get("start_date") or ""),
        reverse=True,
    )

    return render_template(
        "orders/list.html",
        page="orders_list",
        current_orders=current,
        archived_orders=archive,
        today=_ymd(today),
    )


@bp.post("/create", endpoint="create")
def create():
    """
    Приемане на формата от /orders/entry.
    Ако има 'id' -> UPDATE, иначе INSERT.
    Записва в orders.json. След запис – flash и redirect към /orders/ (empty.html).
    """
    form = request.form

    # общи полета
    oid_form = (form.get("id") or "").strip()
    title = form.get("title", "")
    bus_plate = form.get("bus_plate", "")
    start_date = form.get("start_date", "")
    start_time = form.get("start_time", "")
    end_date = form.get("end_date", "")
    end_time = form.get("end_time", "")
    price = form.get("price", "0")
    program = form.get("program", "")
    special_needs = form.get("special_needs", "")
    client_requirements = form.get("client_requirements", "")

    # режими и флагове
    personnel_mode = form.get("personnel_mode", "daily")  # daily|hourly
    second_driver = True if (form.get("second_driver") in ("1", "true", "True", "on")) else False
    round_trip = True if (form.get("round_trip") in ("1", "true", "True", "on")) else False

    # персонал
    daily_rate = form.get("daily_rate", "")
    hourly_rate = form.get("hourly_rate", "")
    hours_per_day = form.get("hours_per_day", "")
    daily_rate2 = form.get("daily_rate2", "")
    days_second = form.get("days_second", "")

    # бюджетни тагове
    budget1_tag_date = form.get("budget1_tag_date", "")
    budget2_tag_date = form.get("budget2_tag_date", "")

    # сегменти
    seg_country = form.getlist("seg_country[]")
    seg_km = form.getlist("seg_km[]")
    seg_toll = form.getlist("seg_toll_cost[]")
    seg_fuel = form.getlist("seg_fuel_cost[]")
    seg_scope = form.getlist("seg_toll_scope[]")

    # други разходи
    extra_desc = form.getlist("extra_desc[]")
    extra_amt = form.getlist("extra_amount[]")
    extra_scope = form.getlist("extra_scope[]")

    store = _load_json(ORDERS_FILE, {"orders": [], "next_id": 1})

    # Подготви сегменти (държави/км)
    seg_len = max(
        len(seg_country),
        len(seg_km),
        len(seg_toll),
        len(seg_fuel),
        len(seg_scope),
        0,
    )
    segments = []
    for i in range(seg_len):
        # прескачаме празни редове (без км и държава и разходи)
        ctry = seg_country[i] if i < len(seg_country) else ""
        kms = seg_km[i] if i < len(seg_km) else ""
        toll = seg_toll[i] if i < len(seg_toll) else "0"
        fuel = seg_fuel[i] if i < len(seg_fuel) else "0"
        scope_v = seg_scope[i] if i < len(seg_scope) else "firm"
        if not (ctry or kms or toll or fuel):
            continue
        segments.append(
            {
                "country": ctry,
                "km": kms or "0",
                "toll_cost": toll or "0",
                "fuel_cost": fuel or "0",
                "scope": scope_v or "firm",
            }
        )

    # Подготви "други разходи"
    extra_len = max(len(extra_desc), len(extra_amt), len(extra_scope), 0)
    extras = []
    for i in range(extra_len):
        desc = extra_desc[i] if i < len(extra_desc) else ""
        amt = extra_amt[i] if i < len(extra_amt) else ""
        scp = extra_scope[i] if i < len(extra_scope) else "firm"
        if not (desc or amt):
            continue
        extras.append(
            {
                "desc": desc,
                "amount": amt or "0",
                "scope": scp or "firm",
            }
        )

    # Сглобяване на обекта
    base_fields = {
        "title": title,
        "bus_plate": bus_plate,
        "start_date": start_date,
        "start_time": start_time,
        "end_date": end_date or start_date,
        "end_time": end_time or start_time,
        "price": price,
        "program": program,
        "special_needs": special_needs,
        "client_requirements": client_requirements,
        "segments": segments,
        "extras": extras,
        "status": "Планирана",
        # персонал
        "personnel_mode": personnel_mode,  # daily|hourly
        "second_driver": second_driver,
        "daily_rate": daily_rate,
        "hourly_rate": hourly_rate,
        "hours_per_day": hours_per_day,
        "daily_rate2": daily_rate2,
        "days_second": days_second,
        # флагове/таг
        "round_trip": round_trip,
        "budget1_tag_date": budget1_tag_date,
        "budget2_tag_date": budget2_tag_date,
    }

    if oid_form:
        # UPDATE
        o = _find_order(store, oid_form)
        if not o:
            flash(f"Поръчка #{oid_form} не е намерена – създадена е нова.", "warning")
            oid = store.get("next_id", 1)
            base_fields["id"] = oid
            store.setdefault("orders", []).append(base_fields)
            store["next_id"] = oid + 1
        else:
            # обнови място
            for k, v in base_fields.items():
                o[k] = v
            # гаранция да не изгубим id
            o["id"] = o.get("id") or int(oid_form)
        _save_json(ORDERS_FILE, store)
        flash(f"Поръчка #{o.get('id') if oid_form else base_fields['id']} е обновена.", "success")
    else:
        # INSERT
        oid = store.get("next_id", 1)
        base_fields["id"] = oid
        store.setdefault("orders", []).append(base_fields)
        store["next_id"] = oid + 1
        _save_json(ORDERS_FILE, store)
        flash("Поръчката е записана.", "success")

    # Връщаме към началната страница (empty.html)
    return redirect(url_for("orders.index"))


# ------------------ DELETE (HTML + API) ------------------
@bp.post("/delete/<int:oid>", endpoint="delete")
def delete_order(oid: int):
    """Изтрива поръчка по ID и връща към списъка (HTML форма)."""
    store = _load_json(ORDERS_FILE, {"orders": [], "next_id": 1})
    before = len(store.get("orders", []))
    store["orders"] = [o for o in store.get("orders", []) if int(o.get("id", -1)) != int(oid)]
    after = len(store.get("orders", []))
    _save_json(ORDERS_FILE, store)
    if after < before:
        flash(f"Поръчка #{oid} е изтрита.", "success")
    else:
        flash(f"Поръчка #{oid} не беше намерена.", "warning")
    return redirect(url_for("orders.list"))


@bp.post("/api/delete", endpoint="api_delete")
def api_delete():
    """
    JSON API: {id: <int>} -> трие записа. Връща {"ok": true, "deleted": true/false}
    """
    try:
        payload = request.get_json(force=True) or {}
    except Exception:
        payload = {}
    oid = payload.get("id", None)
    try:
        if oid is not None:
            oid = int(oid)
    except Exception:
        oid = None

    if oid is None:
        return jsonify({"ok": False, "error": "missing or invalid id"}), 400

    store = _load_json(ORDERS_FILE, {"orders": [], "next_id": 1})
    before = len(store.get("orders", []))
    store["orders"] = [o for o in store.get("orders", []) if int(o.get("id", -1)) != int(oid)]
    after = len(store.get("orders", []))
    deleted = after < before
    if deleted:
        _save_json(ORDERS_FILE, store)
    return jsonify({"ok": True, "deleted": deleted})


# ------------------ APIs ------------------
@bp.get("/api/list", endpoint="api_list")
def api_orders_list():
    """Връща всички поръчки (точно както са записани)."""
    store = _load_json(ORDERS_FILE, {"orders": [], "next_id": 1})
    return jsonify({"orders": store.get("orders", [])})


@bp.get("/api/calendar_flat", endpoint="api_calendar_flat")
def api_orders_calendar_flat():
    """Плосък списък от поръчки по дни (за календар)."""
    store = _load_json(ORDERS_FILE, {"orders": [], "next_id": 1})
    raw = store.get("orders", []) or []

    flat = []
    for o in raw:
        title = (
            o.get("title")
            or (o.get("origin") and f"{o.get('origin')} \u2192 {o.get('destination')}")
            or f"Поръчка #{o.get('id')}"
        )
        plate = o.get("vehicle_plate") or o.get("bus_plate") or ""
        t_start = o.get("start_time") or o.get("startTime") or "08:00"
        t_end = o.get("end_time") or o.get("endTime") or "10:00"
        status = o.get("status") or "Планирана"
        desc = o.get("program") or o.get("description") or ""

        sd = o.get("start_date") or o.get("date")
        ed = o.get("end_date") or o.get("date") or o.get("start_date")
        sdt = _parse_iso_date(sd)
        edt = _parse_iso_date(ed) or sdt
        if not sdt:
            continue

        for d in _daterange(sdt, edt):
            flat.append(
                {
                    "id": str(o.get("id")),
                    "title": title,
                    "date": _ymd(d),
                    "startTime": t_start,
                    "endTime": t_end,
                    "vehicle_plate": plate,
                    "status": status,
                    "description": desc,
                }
            )

    flat.sort(key=lambda x: (x["date"], x.get("vehicle_plate", ""), x["id"]))
    return jsonify({"orders": flat})


@bp.post("/api/update_range", endpoint="api_update_range")
def api_update_range():
    """Обновява диапазона (start/end) + по желание табела и статус."""
    try:
        payload = request.get_json(force=True) or {}
    except Exception:
        payload = {}

    oid = str(payload.get("id") or "").strip()
    sd = payload.get("start_date")
    ed = payload.get("end_date")
    plate = payload.get("vehicle_plate", None)  # None -> не пипай табелата
    status = payload.get("status", None)  # None -> не пипай статуса

    if not oid or not sd:
        return jsonify({"ok": False, "error": "missing id or start_date"}), 400
    if not _parse_iso_date(sd) or (ed and not _parse_iso_date(ed)):
        return jsonify({"ok": False, "error": "invalid dates"}), 400

    store = _load_json(ORDERS_FILE, {"orders": [], "next_id": 1})
    changed = False
    for o in store.get("orders", []):
        if str(o.get("id")) == oid:
            o["start_date"] = sd
            o["end_date"] = ed or sd
            if plate is not None:
                o["vehicle_plate"] = plate
                o["bus_plate"] = plate
            if status:
                o["status"] = status
            changed = True
            break

    if changed:
        _save_json(ORDERS_FILE, store)

    return jsonify({"ok": True, "changed": changed})


@bp.post("/api/set_status", endpoint="api_set_status")
def api_set_status():
    """Сетва статус на поръчка по id."""
    try:
        payload = request.get_json(force=True) or {}
    except Exception:
        payload = {}

    oid = str(payload.get("id", "")).strip()
    status = (payload.get("status") or "").strip()
    if not oid or not status:
        return jsonify({"ok": False, "error": "missing fields"}), 400

    store = _load_json(ORDERS_FILE, {"orders": [], "next_id": 1})
    changed = False
    for o in store.get("orders", []):
        if str(o.get("id")) == oid:
            o["status"] = status
            changed = True
            break

    if changed:
        _save_json(ORDERS_FILE, store)

    return jsonify({"ok": True, "changed": changed})
