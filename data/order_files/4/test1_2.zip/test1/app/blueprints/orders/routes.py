# -*- coding: utf-8 -*-
from flask import Blueprint, render_template, request, redirect, url_for, flash
from datetime import datetime
from sqlalchemy import desc

# Важна промяна: импорт на db от app.extensions (factory pattern),
# а НЕ `from app import db`, което води до ImportError при create_app().
from ...extensions import db

# Ако моделът Order е в този пакет: app/blueprints/orders/models.py
# иначе сменете импорта към `from ...models import Order`
from .models import Order

bp = Blueprint(
    "orders",
    __name__,
    url_prefix="/orders",
    template_folder="templates"  # очаква templates/orders/*.html в този пакет
)

def _parse_date(val):
    if not val:
        return None
    try:
        return datetime.strptime(val, "%Y-%m-%d").date()
    except ValueError:
        return None

@bp.route("/", methods=["GET"])
def list_orders():
    q = Order.query
    if hasattr(Order, "created_at"):
        q = q.order_by(desc(Order.created_at))
    else:
        q = q.order_by(desc(Order.id))
    orders = q.all()
    return render_template("orders/list.html", orders=orders)

@bp.route("/new", methods=["GET"])
def new_order():
    return render_template("orders/entry.html", order=None)

@bp.route("/create", methods=["POST"])
def create_order():
    o = Order()
    o.client_name = request.form.get("client_name") or ""
    o.route_name = request.form.get("route_name") or ""
    o.start_date = _parse_date(request.form.get("start_date"))
    o.end_date = _parse_date(request.form.get("end_date"))
    o.status = request.form.get("status") or "чернова"
    o.currency = request.form.get("currency") or "EUR"

    def _get_number(name):
        raw = request.form.get(name)
        if raw in (None, "", "None"):
            return None
        try:
            return float(raw)
        except Exception:
            return None

    o.price_total = _get_number("price_total")
    o.expected_costs = _get_number("expected_costs")
    o.actual_costs = _get_number("actual_costs")
    o.notes = request.form.get("notes")

    db.session.add(o)
    db.session.commit()

    flash("Поръчката е създадена.", "success")

    if request.form.get("action") == "save_close":
        nxt = request.form.get("next") or url_for("orders.list_orders")
        return redirect(nxt)
    return redirect(url_for("orders.edit_order", order_id=o.id))

@bp.route("/<int:order_id>/edit", methods=["GET"])
def edit_order(order_id):
    o = Order.query.get_or_404(order_id)
    return render_template("orders/entry.html", order=o)

@bp.route("/<int:order_id>/update", methods=["POST"])
def update_order(order_id):
    o = Order.query.get_or_404(order_id)

    o.client_name = request.form.get("client_name") or o.client_name
    o.route_name = request.form.get("route_name") or o.route_name
    o.start_date = _parse_date(request.form.get("start_date"))
    o.end_date = _parse_date(request.form.get("end_date"))
    o.status = request.form.get("status") or o.status
    o.currency = request.form.get("currency") or o.currency

    def _get_number(name, default=None):
        raw = request.form.get(name)
        if raw in (None, "", "None"):
            return default
        try:
            return float(raw)
        except Exception:
            return default

    o.price_total = _get_number("price_total", o.price_total)
    o.expected_costs = _get_number("expected_costs", o.expected_costs)
    o.actual_costs = _get_number("actual_costs", o.actual_costs)
    o.notes = request.form.get("notes")

    db.session.commit()
    flash("Промените са запазени.", "success")

    if request.form.get("action") == "save_close":
        nxt = request.form.get("next") or url_for("orders.list_orders")
        return redirect(nxt)
    return redirect(url_for("orders.edit_order", order_id=o.id))

@bp.route("/<int:order_id>", methods=["GET"])
def view_order(order_id):
    o = Order.query.get_or_404(order_id)
    return render_template("orders/view.html", order=o)
