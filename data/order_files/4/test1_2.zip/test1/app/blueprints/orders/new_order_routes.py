
from flask import request, redirect, url_for, flash
from pathlib import Path
import json
from . import bp
from .costs import compute_costs

ROOT = Path(__file__).resolve().parents[3]
ORDERS_FILE = ROOT / "data" / "orders.json"
BUSES_FILE = ROOT / "data" / "buses.json"
SETTINGS_FILE = ROOT / "data" / "settings.json"

def _load_json(path, default):
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.loads(path.read_text(encoding="utf-8"))

def _save_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def _to_float(x, default=0.0):
    try:
        if x is None: return default
        s = str(x).replace(',', '.').strip()
        return float(s) if s else default
    except Exception:
        return default

@bp.route("/create", methods=["POST"])
def create():
    form = request.form

    store = _load_json(ORDERS_FILE, {"orders": [], "next_id": 1})
    settings = _load_json(SETTINGS_FILE, {"countries": []})
    buses = _load_json(BUSES_FILE, {"buses": []})

    bus_plate = (form.get("bus_plate") or "").strip()
    bus = next((b for b in (buses.get("buses") or []) if (b.get("plate") or "") == bus_plate), {})

    # Basic fields
    order = {
        "id": str(store.get("next_id", 1)),
        "title": (form.get("title") or "").strip(),
        "bus_plate": bus_plate,
        "start_date": (form.get("start_date") or "").strip(),
        "start_time": (form.get("start_time") or "").strip(),
        "end_date": (form.get("end_date") or "").strip(),
        "end_time": (form.get("end_time") or "").strip(),
        "program": (form.get("program") or "").strip(),
        "special_needs": (form.get("special_needs") or "").strip(),
        "client_requirements": (form.get("client_requirements") or "").strip(),
        "price": _to_float(form.get("price")),
        "round_trip": True if form.get("round_trip") else False,
        "status": "PLANNED",
    }

    # Segments (parallel arrays)
    seg_country = request.form.getlist("seg_country[]")
    seg_km = request.form.getlist("seg_km[]")
    seg_fuel_cost = request.form.getlist("seg_fuel_cost[]")
    seg_toll_cost = request.form.getlist("seg_toll_cost[]")
    seg_toll_scope = request.form.getlist("seg_toll_scope[]")

    segments = []
    for i in range(max(len(seg_country), len(seg_km))):
        country = (seg_country[i] if i < len(seg_country) else "").strip()
        km = _to_float(seg_km[i] if i < len(seg_km) else 0.0)
        fuel_cost = _to_float(seg_fuel_cost[i] if i < len(seg_fuel_cost) else 0.0)
        toll_cost = _to_float(seg_toll_cost[i] if i < len(seg_toll_cost) else 0.0)
        scope = (seg_toll_scope[i] if i < len(seg_toll_scope) else "").strip() or "firm"
        if country or km or fuel_cost or toll_cost:
            segments.append({
                "country": country, "km": km,
                "fuel_cost": fuel_cost,
                "toll": {"scope": scope, "amount": toll_cost}
            })
    order["segments"] = segments

    # Extras
    extra_desc = request.form.getlist("extra_desc[]")
    extra_amount = request.form.getlist("extra_amount[]")
    extras = []
    for i in range(max(len(extra_desc), len(extra_amount))):
        desc = (extra_desc[i] if i < len(extra_desc) else "").strip()
        amount = _to_float(extra_amount[i] if i < len(extra_amount) else 0.0)
        if desc or amount:
            extras.append({"desc": desc, "amount": amount})
    # Personnel (single position from form; extra driver not posted via name attrs)
    daily_rate = _to_float(form.get("daily_rate"))
    hourly_rate = _to_float(form.get("hourly_rate"))
    hours_per_day = _to_float(form.get("hours_per_day"))

    # Build planned.costs
    # Aggregate per-country km and fuel from segments
    countries_acc = {}
    for s in segments:
        nm = s.get("country") or ""
        if not nm: continue
        row = countries_acc.get(nm) or {"country": nm, "km": 0.0, "fuel": 0.0}
        row["km"] += _to_float(s.get("km"))
        row["fuel"] += _to_float(s.get("fuel_cost"))
        countries_acc[nm] = row
    countries_rows = list(countries_acc.values())

    tolls_rows = [{"scope": s["toll"]["scope"], "amount": _to_float(s["toll"]["amount"])} for s in segments if s.get("toll")]

    planned = {
        "costs": {
            "countries": countries_rows,
            "tolls": tolls_rows,
            "extras": extras,
            "personnel": {
                "main": {"mode": "daily" if daily_rate else ("hourly" if hourly_rate else ""), "rate": daily_rate or hourly_rate, "hours": hours_per_day if hourly_rate else 0},
                "extra_enabled": False,
                "extra": {"mode":"daily", "rate":0, "hours":0},
            }
        }
    }
    order["planned"] = planned

    # Expected costs via engine
    bus_info = {"fuel_consumption": bus.get("fuel_consumption"), "tank_size": bus.get("tank_size")}
    costs = compute_costs(order=order, bus=bus_info, settings=settings)
    order["expected_costs"] = costs

    # Persist
    store["orders"].append(order)
    store["next_id"] = int(store.get("next_id", 1)) + 1
    _save_json(ORDERS_FILE, store)

    flash("Поръчката е добавена.", "success")
    return redirect(url_for("orders.index"))
