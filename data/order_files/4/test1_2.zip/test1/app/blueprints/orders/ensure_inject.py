# app/blueprints/orders/ensure_inject.py
# Purpose: make sure app_context_processor from context_inject.py is executed.
from . import bp  # ensure blueprint exists before importing injector

ACTIVATED = False
ERROR = None

try:
    from .context_inject import inject_orders_dropdowns  # noqa: F401
    ACTIVATED = True
except Exception as e:
    ERROR = repr(e)

def activate_orders_injection():
    return ACTIVATED
