from datetime import datetime

def days_between(start_date, end_date):
    s = datetime.fromisoformat(start_date)
    e = datetime.fromisoformat(end_date)
    return max(1, (e - s).days + 1)

def compute_costs(order, bus, settings):
    countries = {c["name"]: {
        "fee_per_km": float(c.get("fee_per_km") or 0),
        "fee_per_day": float(c.get("fee_per_day") or 0),
        "fuel_price": float(c.get("fuel_price") or 0),
        "vat_percent": float(c.get("vat_percent") or 0),
    } for c in settings.get("countries", [])}

    segs = order.get("segments") or []
    one_way_km = sum(float(s.get("km") or 0) for s in segs)
    total_km = one_way_km * (2 if order.get("round_trip") else 1)
    days = days_between(order["start_date"], order["end_date"])

    km_fee_per_country = {}
    fuel_cost_per_country = {}

    # KM fees per country (+ RT factor)
    for s in segs:
        country = s.get("country")
        km = float(s.get("km") or 0)
        fee_km = countries.get(country, {}).get("fee_per_km", 0.0)
        km_fee_per_country[country] = km_fee_per_country.get(country, 0.0) + km * fee_km * (2 if order.get("round_trip") else 1)

    # Fee per day — spread by distance share
    total_one_way_km = one_way_km if one_way_km > 0 else 1.0
    for s in segs:
        country = s.get("country")
        km = float(s.get("km") or 0)
        share = km / total_one_way_km
        fee_day = countries.get(country, {}).get("fee_per_day", 0.0)
        if fee_day > 0:
            km_fee_per_country[country] = km_fee_per_country.get(country, 0.0) + fee_day * days * share * (2 if order.get("round_trip") else 1)

    # Fuel simulation
    fuel_consumption = float(order.get("bus_fuel_consumption") or bus.get("fuel_consumption") or 0)  # l/100km
    tank_size = float(order.get("bus_tank_size") or bus.get("tank_size") or 0)                        # l

    fuel_liters_total = (total_km / 100.0) * fuel_consumption
    remaining = tank_size
    route = [(s["country"], float(s["km"] or 0)) for s in segs]
    if order.get("round_trip"):
        route += list(reversed(route))

    km_per_liter = 100.0 / fuel_consumption if fuel_consumption > 0 else float('inf')

    for country, km in route:
        if fuel_consumption <= 0:
            break
        segment_liters_needed = (km / 100.0) * fuel_consumption
        possible_km = remaining * km_per_liter
        if possible_km >= km:
            remaining -= segment_liters_needed
        else:
            if possible_km > 0:
                km -= possible_km
                remaining = 0.0
            needed_liters_now = min(tank_size, (km / 100.0) * fuel_consumption)
            price = countries.get(country, {}).get("fuel_price", 0.0)
            fuel_cost_per_country[country] = fuel_cost_per_country.get(country, 0.0) + needed_liters_now * price
            remaining += needed_liters_now
            burn = (km / 100.0) * fuel_consumption
            remaining = max(0.0, remaining - burn)

    # Driver costs
    d_rate = float(order.get("daily_rate") or 0.0)
    h_rate = float(order.get("hourly_rate") or 0.0)
    h_per_day = float(order.get("hours_per_day") or 0.0)
    driver_daily_cost = d_rate * days
    driver_hourly_cost = h_rate * h_per_day * days
    driver_cost_total = min(x for x in [driver_daily_cost, driver_hourly_cost] if x > 0) if (d_rate or h_rate) else 0.0
    driver_mode = "daily" if driver_daily_cost <= driver_hourly_cost else "hourly"

    km_fees_total = sum(km_fee_per_country.values()) if km_fee_per_country else 0.0
    fuel_cost_total = sum(fuel_cost_per_country.values()) if fuel_cost_per_country else 0.0

    # VAT
    vat_total = 0.0
    for country in set(list(km_fee_per_country.keys()) + list(fuel_cost_per_country.keys())):
        vat_pct = countries.get(country, {}).get("vat_percent", 0.0) / 100.0
        base = (km_fee_per_country.get(country, 0.0) + fuel_cost_per_country.get(country, 0.0))
        vat_total += base * vat_pct

    total_wo_vat = km_fees_total + fuel_cost_total + driver_cost_total
    total_with_vat = total_wo_vat + vat_total

    return {
        "days": days,
        "total_km_one_way": round(one_way_km, 2),
        "total_km": round(total_km, 2),
        "km_fees_total": round(km_fees_total, 2),
        "fuel_liters_total": round(fuel_liters_total, 2),
        "fuel_cost_total": round(fuel_cost_total, 2),
        "driver_cost": round(driver_cost_total, 2),
        "driver_daily_cost": round(driver_daily_cost, 2),
        "driver_hourly_cost": round(driver_hourly_cost, 2),
        "driver_mode_selected": driver_mode,
        "vat_total": round(vat_total, 2),
        "total_expected_cost_wo_vat": round(total_wo_vat, 2),
        "total_expected_cost_with_vat": round(total_with_vat, 2),
        "km_fee_per_country": {k: round(v, 2) for k, v in km_fee_per_country.items()},
        "fuel_cost_per_country": {k: round(v, 2) for k, v in fuel_cost_per_country.items()},
    }
