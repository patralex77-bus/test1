from pathlib import Path
import json
from . import bp

ROOT = Path(__file__).resolve().parents[3]
BUSES_FILE = ROOT / "data" / "buses.json"
SETTINGS_FILE = ROOT / "data" / "settings.json"
ORDERS_FILE = ROOT / "data" / "orders.json"

def _load_json(path, default):
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.loads(path.read_text(encoding="utf-8"))

@bp.app_context_processor
def inject_orders_dropdowns():
    try:
        buses_store = _load_json(BUSES_FILE, {"buses": [], "next_bus_id": 1})
        settings = _load_json(SETTINGS_FILE, {"countries": []})
        orders_store = _load_json(ORDERS_FILE, {"orders": [], "next_id": 1})
        bus_plates = [b.get("reg_no") for b in buses_store.get("buses", []) if (b.get("reg_no") or "").strip()]
        countries = sorted(settings.get("countries", []), key=lambda c: (c.get("name") or "").lower())
        orders = list(orders_store.get("orders", []))
    except Exception:
        bus_plates, countries, orders = [], [], []
    return dict(bus_plates=bus_plates, countries=countries, orders=orders)
