
from flask import render_template
from . import bp

@bp.route("/")
def index():
    return render_template("drivers/index.html", page="drivers")


@bp.route('/portal')
def portal():
    return render_template('drivers/portal.html', page='drivers')
