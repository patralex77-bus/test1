from flask import Blueprint, render_template, request, redirect, url_for, flash
import json
from pathlib import Path

# Уникално име, за да няма конфликт със стар blueprint "settings"
bp = Blueprint("settings_countries", __name__, url_prefix="/settings")

ROOT = Path(__file__).resolve().parents[3]
DATA_FILE = ROOT / "data" / "settings.json"

def _load():
    if not DATA_FILE.exists():
        DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
        DATA_FILE.write_text(json.dumps({"countries": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.loads(DATA_FILE.read_text(encoding="utf-8"))

def _save(store):
    DATA_FILE.write_text(json.dumps(store, ensure_ascii=False, indent=2), encoding="utf-8")

# 👉 ДОБАВЕНО: /settings/ → redirect към /settings/countries
@bp.route("/", methods=["GET"])
def index():
    return redirect(url_for("settings_countries.countries"))

@bp.route("/countries", methods=["GET", "POST"])
def countries():
    store = _load()
    if request.method == "POST":
        form = request.form
        name = (form.get("name") or "").strip()
        fee_per_km = float(form.get("fee_per_km") or 0.0)
        fee_per_day = float(form.get("fee_per_day") or 0.0)
        fuel_price = float(form.get("fuel_price") or 0.0)
        vat_percent = float(form.get("vat_percent") or 0.0)
        if not name:
            flash("Въведете държава.", "warning")
            return redirect(url_for("settings_countries.countries"))
        existing = next((c for c in store["countries"] if c["name"].lower() == name.lower()), None)
        payload = {
            "name": name,
            "fee_per_km": fee_per_km,
            "fee_per_day": fee_per_day,
            "fuel_price": fuel_price,
            "vat_percent": vat_percent
        }
        if existing:
            existing.update(payload)
            flash("Обновихте държавата.", "success")
        else:
            store["countries"].append(payload)
            flash("Добавихте държава.", "success")
        _save(store)
        return redirect(url_for("settings_countries.countries"))

    countries = sorted(_load()["countries"], key=lambda x: x["name"].lower())
    return render_template("settings/countries.html", page="settings", countries=countries)

@bp.route("/countries/delete/<name>", methods=["POST"])
def delete_country(name):
    store = _load()
    before = len(store["countries"])
    store["countries"] = [c for c in store["countries"] if c["name"] != name]
    _save(store)
    flash("Изтрихте държавата." if len(store["countries"]) < before else "Държавата не е намерена.", "info")
    return redirect(url_for("settings_countries.countries"))
