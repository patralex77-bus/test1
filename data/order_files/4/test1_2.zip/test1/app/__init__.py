from flask import Flask, redirect, url_for

def create_app():
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config["SECRET_KEY"] = "change-me"
    app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0  # dev: disable static file caching

    # ---- Blueprints (без дублиране!) ----
    from .blueprints.calendar import bp as calendar_bp
    from .blueprints.buses import bp as buses_bp
    from .blueprints.drivers import bp as drivers_bp
    from .blueprints.stats import bp as stats_bp
    from .blueprints.orders import bp as orders_bp

    # ВАЖНО: нашият нов “Държави” blueprint е с уникално име settings_countries
    # и вече има url_prefix="/settings" в самия Blueprint.
    from app.blueprints.settings.routes import bp as settings_countries_bp

    # ---- Регистрация (по веднъж всеки) ----
    app.register_blueprint(calendar_bp, url_prefix="/calendar")
    app.register_blueprint(buses_bp, url_prefix="/buses")
    app.register_blueprint(drivers_bp, url_prefix="/drivers")
    app.register_blueprint(stats_bp, url_prefix="/stats")
    app.register_blueprint(orders_bp, url_prefix="/orders")
    app.register_blueprint(settings_countries_bp)  # НЕ добавяй втори път /settings тук

    @app.route("/")
    def root():
        return redirect(url_for("calendar.index"))

    return app
